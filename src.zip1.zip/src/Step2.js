import { useState,useContext } from 'react';
import { Context } from "./Context.js";

function Step2() {
    const [context,setContext] = useContext(Context);
    console.log('context',context)
    const [row,setRow] = useState(0);
    const [col,setCol] = useState(0);
    const [matrixReady,SetMatrixReady] = useState(false);
    const createMatrix = (row,col)=>{
      return Array(5).fill(0).map(row1 => Array(5).fill(1).map((col1,index)=>(
        <div key={`row-${row1}-col-${col1}`} className="flip-box-inner">{index}</div>
    )));
    }
    const renderMatrix = ()=>{
      //TO DO with dynamic row and col
      SetMatrixReady(true);
    }
    return (
      <div>
              <div className="row">
      ROW:<input type="text" value={row} onChange={(event)=>{
        setRow(event.target.value)
      }
    }/>
      COL:<input type="text" value={col} onChange={(event)=>{
        setCol(event.target.value)
      }
    }/>
    <button onClick={renderMatrix}>Render Matrix</button>
    <div className="col-md-12">
      <div className="flip-box">
      {
      matrixReady && (createMatrix())
    }</div>
    </div>
  </div>
      </div>
    );
  }
  
  export default Step2;