import { useState,useContext } from 'react';
import React from "react";
import { Context } from "./Context.js";

function Step1() {
  const [context,setContext] = useContext(Context);

  const [rows,setRows] = useState(0);
  const [cols,setCols] = useState(0);
  const [obs,setObs] = useState(0);
  return (
    <div>
        Rows: <input type="range" value={rows} min="0" max="10" step="1" onChange={(event)=>{
          setRows(event.target.value);
        }}/>
        Columns: <input type="range" value={cols} min="0" max="10" step="1" onChange={(event)=>{
          setCols(event.target.value);
        }}/>
        Obstructions: <input type="range" value={obs} min="0" max="5" step="1" onChange={(event)=>{
          setObs(event.target.value);
        }}/>
        <button onClick={()=>{
          setContext({
            ...context,
            step: 2,
            rows,
            cols,
            obs,
          })
        }}>Submit</button>
    </div>
  );
}

export default Step1;